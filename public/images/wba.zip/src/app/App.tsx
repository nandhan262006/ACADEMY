import { useState, useEffect, useRef } from "react";
import { Menu, X, ArrowRight, Play, Instagram } from "lucide-react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import logoImg from "@/imports/LOGO.png";

// ─── Image catalogue ──────────────────────────────────────────────────────────
const IMGS = {
  hero:    { src: "https://images.unsplash.com/photo-1762708594285-fb55302623fe?w=1920&h=1080&fit=crop&auto=format&q=85", alt: "Silhouette of bride beneath a sheer veil at golden dusk" },
  story1:  { src: "https://images.unsplash.com/photo-1665960213508-48f07086d49c?w=900&h=1200&fit=crop&auto=format&q=80", alt: "Indian couple in traditional bridal attire" },
  story2:  { src: "https://images.unsplash.com/photo-1727430256509-0f897d6f4765?w=1400&h=900&fit=crop&auto=format&q=80", alt: "Couple beneath a romantic canopy of blooms" },
  story3:  { src: "https://images.unsplash.com/photo-1735052712464-9d24b69be5f5?w=700&h=1050&fit=crop&auto=format&q=80", alt: "Bride and groom on a forest path" },
  story4:  { src: "https://images.unsplash.com/photo-1779810687374-55d9007b9fbb?w=800&h=1200&fit=crop&auto=format&q=80", alt: "Silhouette covered by a sheer wedding veil" },
  story5:  { src: "https://images.unsplash.com/photo-1587271407850-8d438ca9fdf2?w=1400&h=900&fit=crop&auto=format&q=80", alt: "Grand Indian wedding ceremony beneath a gold floral ceiling" },
  couple:  { src: "https://images.unsplash.com/photo-1559460547-932cc4939506?w=900&h=1200&fit=crop&auto=format&q=80", alt: "Couple in an intimate moment at dusk" },
  about:   { src: "https://images.unsplash.com/photo-1519741196428-6a2175fa2557?w=900&h=1100&fit=crop&auto=format&q=80", alt: "Intimate wedding portrait" },
  film:    { src: "https://images.unsplash.com/photo-1587271636175-90d58cdad458?w=1400&h=900&fit=crop&auto=format&q=80", alt: "Grand Indian wedding ceremony" },
  ig1:     { src: "https://images.unsplash.com/photo-1614618586684-7afae48a15d3?w=600&h=600&fit=crop&auto=format&q=75", alt: "Bridal portrait in floral gown" },
  ig2:     { src: "https://images.unsplash.com/photo-1735052712489-f45220126a0c?w=600&h=600&fit=crop&auto=format&q=75", alt: "Bride and groom at sunset" },
  ig3:     { src: "https://images.unsplash.com/photo-1488846343176-08e05ab9a2a1?w=600&h=600&fit=crop&auto=format&q=75", alt: "Serene bride with eyes closed" },
  ig4:     { src: "https://images.unsplash.com/photo-1630526720753-aa4e71acf67d?w=600&h=600&fit=crop&auto=format&q=75", alt: "Bride in red and white traditional dress" },
  ig5:     { src: "https://images.unsplash.com/photo-1501175635532-bdd01562edb2?w=600&h=600&fit=crop&auto=format&q=75", alt: "Bride in wedding veil, soft focus" },
  ig6:     { src: "https://images.unsplash.com/photo-1484849457281-191e439a0431?w=600&h=600&fit=crop&auto=format&q=75", alt: "Wedding gown in natural light" },
};

// ─── Reveal hook ──────────────────────────────────────────────────────────────
function useReveal(threshold = 0.12) {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, visible };
}

// ─── Navbar ───────────────────────────────────────────────────────────────────
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 56);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const links = ["Weddings", "Films", "About", "Contact"];

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-700"
      style={{ background: scrolled ? "rgba(11,11,11,0.97)" : "transparent", borderBottom: scrolled ? "1px solid rgba(201,169,110,0.1)" : "1px solid transparent", backdropFilter: scrolled ? "blur(8px)" : "none" }}
    >
      <div className="max-w-[1680px] mx-auto px-6 lg:px-14 flex items-center justify-between h-[60px] lg:h-[72px]">
        <a href="#hero" style={{ display: "flex", alignItems: "center", gap: "12px", textDecoration: "none" }}>
          <ImageWithFallback
            src={logoImg}
            alt="W/BA — Weddings by Ajay"
            style={{
              height: 38,
              width: 38,
              objectFit: "contain",
              mixBlendMode: "screen",
              display: "block",
              flexShrink: 0,
            }}
          />
          <span
            className="hidden sm:block"
            style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#F5F1EA", fontSize: "10px", letterSpacing: "0.38em", textTransform: "uppercase", fontWeight: 400, opacity: 0.75 }}
          >
            Weddings by Ajay
          </span>
        </a>

        <div className="hidden lg:flex items-center gap-10">
          {links.map(l => (
            <a
              key={l}
              href={`#${l.toLowerCase()}`}
              className="text-[#F5F1EA] text-[10px] tracking-[0.35em] uppercase transition-colors duration-300 hover:text-[#C9A96E]"
              style={{ fontFamily: "'Jost', system-ui, sans-serif", opacity: 0.55, fontWeight: 400 }}
              onMouseEnter={e => (e.currentTarget.style.opacity = "1")}
              onMouseLeave={e => (e.currentTarget.style.opacity = "0.55")}
            >
              {l}
            </a>
          ))}
        </div>

        <button
          className="lg:hidden text-[#F5F1EA] p-1"
          onClick={() => setOpen(v => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X size={19} /> : <Menu size={19} />}
        </button>
      </div>

      {/* Mobile panel */}
      <div
        className="lg:hidden overflow-hidden transition-all duration-500"
        style={{ maxHeight: open ? "220px" : "0px" }}
      >
        <div className="px-6 pb-8 pt-2 flex flex-col gap-6" style={{ borderTop: "1px solid rgba(201,169,110,0.1)", background: "rgba(11,11,11,0.98)" }}>
          {links.map(l => (
            <a
              key={l}
              href={`#${l.toLowerCase()}`}
              onClick={() => setOpen(false)}
              className="text-[#F5F1EA] text-[10px] tracking-[0.35em] uppercase"
              style={{ fontFamily: "'Jost', system-ui, sans-serif", opacity: 0.65 }}
            >
              {l}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  const [ready, setReady] = useState(false);

  return (
    <section id="hero" className="relative overflow-hidden flex items-center justify-center" style={{ height: "100svh", minHeight: "600px" }}>
      <div className="absolute inset-0" style={{ background: "#0B0B0B" }}>
        <img
          src={IMGS.hero.src}
          alt={IMGS.hero.alt}
          loading="eager"
          onLoad={() => setReady(true)}
          className="w-full h-full object-cover object-center"
          style={{ opacity: ready ? 0.52 : 0, transition: "opacity 1.4s ease" }}
        />
      </div>
      {/* cinematic letterbox vignette */}
      <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(11,11,11,0.5) 0%, rgba(11,11,11,0.05) 40%, rgba(11,11,11,0.05) 60%, rgba(11,11,11,0.85) 100%)" }} />
      <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at center, transparent 40%, rgba(11,11,11,0.45) 100%)" }} />

      <div
        className="relative z-10 flex flex-col items-center text-center px-6"
        style={{ opacity: ready ? 1 : 0, transform: ready ? "translateY(0)" : "translateY(20px)", transition: "opacity 1.2s ease 0.4s, transform 1.2s ease 0.4s" }}
      >
        {/* Logo mark — cinematic centerpiece */}
        <div style={{ marginBottom: "clamp(1.5rem, 4vw, 2.5rem)" }}>
          <ImageWithFallback
            src={logoImg}
            alt="W/BA — Weddings by Ajay"
            style={{
              width: "clamp(90px, 14vw, 160px)",
              height: "clamp(90px, 14vw, 160px)",
              objectFit: "contain",
              mixBlendMode: "screen",
              display: "block",
              margin: "0 auto",
            }}
          />
        </div>

        {/* Rule + location */}
        <div className="flex items-center gap-4 mb-8">
          <div style={{ width: 48, height: 1, background: "rgba(201,169,110,0.55)" }} />
          <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase" }}>
            Est. 2016 · Hyderabad, India
          </span>
          <div style={{ width: 48, height: 1, background: "rgba(201,169,110,0.55)" }} />
        </div>

        <h1
          style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            color: "#F5F1EA",
            fontSize: "clamp(2.4rem, 7vw, 6.5rem)",
            letterSpacing: "0.16em",
            textTransform: "uppercase",
            fontWeight: 400,
            lineHeight: 1.05,
            marginBottom: "clamp(0.9rem, 2vw, 1.4rem)",
          }}
        >
          Weddings<br />by Ajay
        </h1>

        <p
          style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontStyle: "italic",
            color: "#C9A96E",
            fontSize: "clamp(1rem, 2.2vw, 1.45rem)",
            letterSpacing: "0.06em",
            marginBottom: "clamp(2.5rem, 5vw, 3.5rem)",
          }}
        >
          Stories that feel like forever.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <a
            href="#weddings"
            style={{
              fontFamily: "'Jost', system-ui, sans-serif",
              fontSize: "10px",
              letterSpacing: "0.28em",
              textTransform: "uppercase",
              color: "#F5F1EA",
              border: "1px solid rgba(245,241,234,0.35)",
              padding: "14px 32px",
              display: "inline-block",
              transition: "all 0.4s ease",
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "#C9A96E"; e.currentTarget.style.color = "#C9A96E"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(245,241,234,0.35)"; e.currentTarget.style.color = "#F5F1EA"; }}
          >
            View Stories
          </a>
          <a
            href="#contact"
            style={{
              fontFamily: "'Jost', system-ui, sans-serif",
              fontSize: "10px",
              letterSpacing: "0.28em",
              textTransform: "uppercase",
              color: "#0B0B0B",
              background: "#C9A96E",
              padding: "14px 32px",
              display: "inline-block",
              fontWeight: 500,
              transition: "background 0.4s ease",
            }}
            onMouseEnter={e => (e.currentTarget.style.background = "#E8D5A3")}
            onMouseLeave={e => (e.currentTarget.style.background = "#C9A96E")}
          >
            Book Your Date
          </a>
        </div>
      </div>

      {/* Scroll pulse */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5" style={{ opacity: ready ? 0.35 : 0, transition: "opacity 1s ease 1.8s" }}>
        <div style={{ width: 1, height: 48, background: "#F5F1EA", animation: "scrollPulse 2s ease-in-out infinite" }} />
      </div>

      <style>{`
        @keyframes scrollPulse {
          0%, 100% { opacity: 0.3; transform: scaleY(1); }
          50% { opacity: 0.8; transform: scaleY(0.6); }
        }
        html { scroll-behavior: smooth; }
        ::-webkit-scrollbar { display: none; }
        * { scrollbar-width: none; }
      `}</style>
    </section>
  );
}

// ─── Brand Statement ──────────────────────────────────────────────────────────
function BrandStatement() {
  const { ref, visible } = useReveal(0.15);

  return (
    <section
      ref={ref}
      style={{ background: "#0B0B0B", padding: "clamp(5rem, 12vw, 11rem) clamp(1.5rem, 5vw, 5rem)" }}
    >
      <div style={{ maxWidth: 1500, margin: "0 auto" }}>
        <div
          className="grid grid-cols-1 lg:grid-cols-[1fr_2fr]"
          style={{ gap: "clamp(3rem, 6vw, 8rem)", alignItems: "center" }}
        >
          {/* Left label */}
          <div
            style={{ opacity: visible ? 1 : 0, transform: visible ? "translateX(0)" : "translateX(-20px)", transition: "opacity 1s ease, transform 1s ease" }}
          >
            <div style={{ width: 40, height: 1, background: "#C9A96E", marginBottom: "1rem" }} />
            <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase", display: "block", marginBottom: "1.2rem" }}>
              Philosophy
            </span>
            <p style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.35)", fontSize: "13px", lineHeight: 1.8 }}>
              Every frame is a deliberate choice. Every moment preserved in its fullest truth — untouched, unrepeatable.
            </p>
          </div>

          {/* Right: large quote */}
          <h2
            style={{
              fontFamily: "'Playfair Display', Georgia, serif",
              color: "#F5F1EA",
              fontSize: "clamp(2.2rem, 5.5vw, 5rem)",
              fontWeight: 400,
              lineHeight: 1.18,
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(24px)",
              transition: "opacity 1.1s ease 0.15s, transform 1.1s ease 0.15s",
            }}
          >
            We don&apos;t just
            <br />
            <em style={{ color: "#C9A96E", fontStyle: "italic" }}>capture</em> weddings.
            <br />
            We preserve the
            <br />
            feeling.
          </h2>
        </div>
      </div>
    </section>
  );
}

// ─── Featured Weddings ────────────────────────────────────────────────────────
const STORIES = [
  { title: "Priya & Arjun",   location: "Hyderabad", year: "2024", type: "Royal Haveli",        img: IMGS.story1 },
  { title: "Meera & Vikram",  location: "Udaipur",   year: "2024", type: "Palace Destination",  img: IMGS.story2 },
  { title: "Ananya & Karan",  location: "Goa",       year: "2023", type: "Beachside Romance",   img: IMGS.story3 },
  { title: "Divya & Rohan",   location: "Delhi",     year: "2023", type: "Heritage Garden",     img: IMGS.story4 },
  { title: "Ishaan & Preet",  location: "Jaipur",    year: "2024", type: "Maharaja Celebration",img: IMGS.story5 },
];

type Story = (typeof STORIES)[0];

function StoryCard({ story, delay, visible, aspectRatio }: { story: Story; delay: number; visible: boolean; aspectRatio: string }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      style={{
        position: "relative",
        overflow: "hidden",
        background: "#111",
        aspectRatio,
        cursor: "pointer",
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(28px)",
        transition: `opacity 1s ease ${delay}ms, transform 1s ease ${delay}ms`,
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <img
        src={story.img.src}
        alt={story.img.alt}
        loading="lazy"
        style={{
          position: "absolute", inset: 0, width: "100%", height: "100%",
          objectFit: "cover",
          transform: hovered ? "scale(1.06)" : "scale(1)",
          transition: "transform 1.6s cubic-bezier(0.25,0.46,0.45,0.94)",
        }}
      />
      {/* gradient */}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,11,11,0.85) 0%, rgba(11,11,11,0.1) 50%, transparent 100%)" }} />

      {/* badge */}
      <div style={{
        position: "absolute", top: 20, right: 20,
        border: "1px solid rgba(201,169,110,0.5)",
        padding: "5px 12px",
        opacity: hovered ? 1 : 0,
        transform: hovered ? "translateY(0)" : "translateY(-6px)",
        transition: "opacity 0.4s ease, transform 0.4s ease",
      }}>
        <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "8px", letterSpacing: "0.3em", textTransform: "uppercase" }}>View Story</span>
      </div>

      {/* info */}
      <div style={{ position: "absolute", bottom: 0, left: 0, padding: "clamp(1.2rem, 3vw, 2rem)" }}>
        <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "8px", letterSpacing: "0.4em", textTransform: "uppercase", display: "block", marginBottom: "0.5rem" }}>
          {story.type} · {story.year}
        </span>
        <h3 style={{ fontFamily: "'Playfair Display', Georgia, serif", color: "#F5F1EA", fontSize: "clamp(1.1rem, 2vw, 1.6rem)", fontWeight: 400, marginBottom: "0.3rem" }}>
          {story.title}
        </h3>
        <p style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.45)", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase" }}>
          {story.location}
        </p>
      </div>
    </div>
  );
}

function FeaturedWeddings() {
  const { ref, visible } = useReveal(0.05);

  return (
    <section id="weddings" ref={ref} style={{ background: "#0B0B0B", paddingBottom: "clamp(4rem, 10vw, 9rem)" }}>
      {/* Header */}
      <div
        style={{
          maxWidth: 1680, margin: "0 auto",
          padding: "clamp(4rem, 8vw, 7rem) clamp(1.5rem, 5vw, 3.5rem) clamp(2rem, 4vw, 3rem)",
          display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: "1.5rem",
          opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(16px)",
          transition: "opacity 0.9s ease, transform 0.9s ease",
        }}
      >
        <div>
          <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase", display: "block", marginBottom: "0.75rem" }}>
            Selected Work
          </span>
          <h2 style={{ fontFamily: "'Playfair Display', Georgia, serif", color: "#F5F1EA", fontSize: "clamp(2rem, 4.5vw, 4rem)", fontWeight: 400 }}>
            Featured Stories
          </h2>
        </div>
        <a
          href="#"
          style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.4)", fontSize: "10px", letterSpacing: "0.3em", textTransform: "uppercase", display: "flex", alignItems: "center", gap: "8px", transition: "color 0.3s ease", textDecoration: "none" }}
          onMouseEnter={e => (e.currentTarget.style.color = "#C9A96E")}
          onMouseLeave={e => (e.currentTarget.style.color = "rgba(245,241,234,0.4)")}
        >
          View All <ArrowRight size={13} />
        </a>
      </div>

      {/* Editorial grid */}
      <div style={{ maxWidth: 1680, margin: "0 auto", padding: "0 clamp(1rem, 2vw, 2rem)" }}>

        {/* Row 1: wide landscape + tall portrait */}
        <div className="grid grid-cols-1 lg:grid-cols-[3fr_2fr] mb-1" style={{ gap: 4, marginBottom: 4 }}>
          <StoryCard story={STORIES[0]} aspectRatio="4/3" delay={0}   visible={visible} />
          <StoryCard story={STORIES[1]} aspectRatio="3/4" delay={80}  visible={visible} />
        </div>

        {/* Row 2: tall portrait + wide landscape */}
        <div className="grid grid-cols-1 lg:grid-cols-[2fr_3fr]" style={{ gap: 4, marginBottom: 4 }}>
          <StoryCard story={STORIES[2]} aspectRatio="3/4" delay={160} visible={visible} />
          <StoryCard story={STORIES[3]} aspectRatio="4/3" delay={240} visible={visible} />
        </div>

        {/* Row 3: full width cinematic */}
        <StoryCard story={STORIES[4]} aspectRatio="21/9" delay={320} visible={visible} />
      </div>
    </section>
  );
}

// ─── Photography + Films ──────────────────────────────────────────────────────
function ServicesSection() {
  const { ref, visible } = useReveal(0.08);
  const [hovPh, setHovPh] = useState(false);
  const [hovFi, setHovFi] = useState(false);

  return (
    <section id="films" ref={ref} style={{ background: "#0B0B0B" }}>
      {/* Divider */}
      <div style={{ maxWidth: 1680, margin: "0 auto", padding: "0 clamp(1.5rem, 5vw, 3.5rem)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "2rem", padding: "clamp(3rem, 6vw, 6rem) 0 clamp(2rem, 4vw, 4rem)" }}>
          <div style={{ flex: 1, height: 1, background: "rgba(201,169,110,0.1)" }} />
          <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase", whiteSpace: "nowrap" }}>
            Services
          </span>
          <div style={{ flex: 1, height: 1, background: "rgba(201,169,110,0.1)" }} />
        </div>
      </div>

      {/* Two halves */}
      <div className="grid grid-cols-1 lg:grid-cols-2">
        {/* Photography */}
        <div
          style={{
            position: "relative", overflow: "hidden",
            height: "clamp(420px, 70vh, 820px)",
            background: "#111",
            cursor: "pointer",
            opacity: visible ? 1 : 0,
            transform: visible ? "translateX(0)" : "translateX(-24px)",
            transition: "opacity 1.1s ease 0.1s, transform 1.1s ease 0.1s",
          }}
          onMouseEnter={() => setHovPh(true)}
          onMouseLeave={() => setHovPh(false)}
        >
          <img
            src={IMGS.couple.src}
            alt={IMGS.couple.alt}
            loading="lazy"
            style={{
              width: "100%", height: "100%", objectFit: "cover",
              transform: hovPh ? "scale(1.06)" : "scale(1)",
              transition: "transform 1.6s cubic-bezier(0.25,0.46,0.45,0.94)",
            }}
          />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,11,11,0.92) 0%, rgba(11,11,11,0.2) 55%, rgba(11,11,11,0.1) 100%)" }} />
          <div style={{ position: "absolute", bottom: 0, left: 0, padding: "clamp(2rem, 4vw, 3.5rem)" }}>
            <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.4em", textTransform: "uppercase", display: "block", marginBottom: "1rem" }}>01 ·</span>
            <h3 style={{ fontFamily: "'Playfair Display', Georgia, serif", color: "#F5F1EA", fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 400, marginBottom: "1rem" }}>Photography</h3>
            <p style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.55)", fontSize: "13px", lineHeight: 1.8, maxWidth: 300, marginBottom: "1.5rem" }}>
              Still frames that hold the weight of a moment. Candid, intimate, editorial — photographs that become heirlooms.
            </p>
            <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
              <div style={{ width: 32, height: 1, background: "#C9A96E" }} />
              <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase" }}>Explore</span>
            </div>
          </div>
        </div>

        {/* Cinematic Films */}
        <div
          style={{
            position: "relative", overflow: "hidden",
            height: "clamp(420px, 70vh, 820px)",
            background: "#111",
            cursor: "pointer",
            opacity: visible ? 1 : 0,
            transform: visible ? "translateX(0)" : "translateX(24px)",
            transition: "opacity 1.1s ease 0.25s, transform 1.1s ease 0.25s",
          }}
          onMouseEnter={() => setHovFi(true)}
          onMouseLeave={() => setHovFi(false)}
        >
          <img
            src={IMGS.film.src}
            alt={IMGS.film.alt}
            loading="lazy"
            style={{
              width: "100%", height: "100%", objectFit: "cover", objectPosition: "center top",
              transform: hovFi ? "scale(1.06)" : "scale(1)",
              transition: "transform 1.6s cubic-bezier(0.25,0.46,0.45,0.94)",
            }}
          />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,11,11,0.92) 0%, rgba(11,11,11,0.35) 55%, rgba(11,11,11,0.15) 100%)" }} />

          {/* Play button */}
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{
              width: 64, height: 64,
              border: `1px solid ${hovFi ? "#C9A96E" : "rgba(201,169,110,0.5)"}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              background: hovFi ? "rgba(201,169,110,0.12)" : "transparent",
              transition: "all 0.4s ease",
            }}>
              <Play size={20} fill="#C9A96E" color="#C9A96E" style={{ marginLeft: 3 }} />
            </div>
          </div>

          <div style={{ position: "absolute", bottom: 0, left: 0, padding: "clamp(2rem, 4vw, 3.5rem)" }}>
            <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.4em", textTransform: "uppercase", display: "block", marginBottom: "1rem" }}>02 ·</span>
            <h3 style={{ fontFamily: "'Playfair Display', Georgia, serif", color: "#F5F1EA", fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 400, marginBottom: "1rem" }}>Cinematic Films</h3>
            <p style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.55)", fontSize: "13px", lineHeight: 1.8, maxWidth: 300, marginBottom: "1.5rem" }}>
              Feature-length wedding films crafted like cinema. Scored with emotion. Made to be rewatched for a lifetime.
            </p>
            <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
              <div style={{ width: 32, height: 1, background: "#C9A96E" }} />
              <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase" }}>Watch Reel</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── About ────────────────────────────────────────────────────────────────────
function AboutSection() {
  const { ref, visible } = useReveal(0.08);

  return (
    <section id="about" ref={ref} style={{ background: "#0B0B0B", padding: "clamp(5rem, 12vw, 11rem) clamp(1.5rem, 5vw, 3.5rem)" }}>
      <div style={{ maxWidth: 1500, margin: "0 auto" }}>
        <div style={{ height: 1, background: "rgba(201,169,110,0.1)", marginBottom: "clamp(3rem, 7vw, 6rem)" }} />

        <div className="grid grid-cols-1 lg:grid-cols-2" style={{ gap: "clamp(3rem, 7vw, 7rem)", alignItems: "start" }}>
          {/* Portrait */}
          <div
            style={{
              position: "relative",
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(28px)",
              transition: "opacity 1.1s ease, transform 1.1s ease",
            }}
          >
            <div style={{ aspectRatio: "4/5", overflow: "hidden", background: "#111" }}>
              <img
                src={IMGS.about.src}
                alt={IMGS.about.alt}
                loading="lazy"
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
            </div>
            {/* Decorative frame offset */}
            <div style={{
              position: "absolute", bottom: -16, right: -16,
              width: "55%", height: "40%",
              border: "1px solid rgba(201,169,110,0.22)",
              pointerEvents: "none",
            }} />
          </div>

          {/* Text */}
          <div
            style={{
              display: "flex", flexDirection: "column", justifyContent: "center",
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(28px)",
              transition: "opacity 1.1s ease 0.2s, transform 1.1s ease 0.2s",
            }}
          >
            <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase", display: "block", marginBottom: "1.5rem" }}>
              About
            </span>
            <h2 style={{ fontFamily: "'Playfair Display', Georgia, serif", color: "#F5F1EA", fontSize: "clamp(2.5rem, 4.5vw, 4rem)", fontWeight: 400, lineHeight: 1.1, marginBottom: "2rem" }}>
              Ajay Kumar
            </h2>
            <p style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.58)", fontSize: "14px", lineHeight: 1.85, marginBottom: "1.25rem" }}>
              Based in Hyderabad, Ajay has spent over a decade perfecting the art of wedding storytelling. What began as a quiet passion for documentary photography has evolved into one of India&apos;s most sought-after wedding studios.
            </p>
            <p style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.58)", fontSize: "14px", lineHeight: 1.85, marginBottom: "2.5rem" }}>
              His approach is rooted in restraint — a belief that the most powerful images are those that feel discovered rather than constructed. He and his team travel across India and internationally, from intimate ceremonies to grand royal celebrations.
            </p>

            <blockquote style={{
              borderLeft: "2px solid #C9A96E",
              paddingLeft: "1.5rem",
              marginBottom: "2.5rem",
            }}>
              <p style={{ fontFamily: "'Playfair Display', Georgia, serif", fontStyle: "italic", color: "rgba(245,241,234,0.78)", fontSize: "clamp(1rem, 1.8vw, 1.25rem)", lineHeight: 1.7 }}>
                &ldquo;I&apos;m not here to make pretty pictures. I&apos;m here to make sure, thirty years from now, you can still feel what that day felt like.&rdquo;
              </p>
            </blockquote>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1.5rem", borderTop: "1px solid rgba(201,169,110,0.1)", paddingTop: "2rem" }}>
              {[["400+", "Weddings"], ["12", "Years"], ["18", "Countries"]].map(([n, l]) => (
                <div key={l}>
                  <div style={{ fontFamily: "'Playfair Display', Georgia, serif", color: "#C9A96E", fontSize: "clamp(1.8rem, 3vw, 2.5rem)", fontWeight: 400, lineHeight: 1, marginBottom: "0.4rem" }}>{n}</div>
                  <div style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.35)", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase" }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Instagram ────────────────────────────────────────────────────────────────
const IG = [IMGS.ig1, IMGS.ig2, IMGS.ig3, IMGS.ig4, IMGS.ig5, IMGS.ig6];

function InstagramSection() {
  const { ref, visible } = useReveal(0.05);
  const [hovIdx, setHovIdx] = useState<number | null>(null);

  return (
    <section id="contact" ref={ref} style={{ background: "#0B0B0B", paddingTop: "clamp(4rem, 10vw, 8rem)" }}>
      {/* Header */}
      <div
        style={{
          maxWidth: 1680, margin: "0 auto",
          padding: "0 clamp(1.5rem, 5vw, 3.5rem) clamp(2.5rem, 5vw, 4rem)",
          display: "flex", flexWrap: "wrap", alignItems: "flex-end", justifyContent: "space-between", gap: "1.5rem",
          opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(16px)",
          transition: "opacity 0.9s ease, transform 0.9s ease",
        }}
      >
        <div>
          <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase", display: "block", marginBottom: "0.75rem" }}>
            Follow the Stories
          </span>
          <h2 style={{ fontFamily: "'Playfair Display', Georgia, serif", color: "#F5F1EA", fontSize: "clamp(1.8rem, 4vw, 3.5rem)", fontWeight: 400 }}>
            @weddingsbyajay
          </h2>
        </div>
        <a
          href="https://instagram.com/weddingsbyajay"
          target="_blank"
          rel="noopener noreferrer"
          style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.4)", fontSize: "10px", letterSpacing: "0.3em", textTransform: "uppercase", display: "flex", alignItems: "center", gap: "8px", textDecoration: "none", transition: "color 0.3s ease" }}
          onMouseEnter={e => (e.currentTarget.style.color = "#C9A96E")}
          onMouseLeave={e => (e.currentTarget.style.color = "rgba(245,241,234,0.4)")}
        >
          <Instagram size={13} /> Follow on Instagram
        </a>
      </div>

      {/* Grid — 3×2 desktop, 2×3 mobile */}
      <div className="grid grid-cols-2 md:grid-cols-3" style={{ gap: 2 }}>
        {IG.map((img, i) => (
          <div
            key={i}
            style={{
              position: "relative", overflow: "hidden", background: "#111",
              aspectRatio: "1/1", cursor: "pointer",
              opacity: visible ? 1 : 0,
              transform: visible ? "scale(1)" : "scale(0.97)",
              transition: `opacity 0.9s ease ${i * 70}ms, transform 0.9s ease ${i * 70}ms`,
            }}
            onMouseEnter={() => setHovIdx(i)}
            onMouseLeave={() => setHovIdx(null)}
          >
            <img
              src={img.src}
              alt={img.alt}
              loading="lazy"
              style={{
                width: "100%", height: "100%", objectFit: "cover",
                transform: hovIdx === i ? "scale(1.08)" : "scale(1)",
                transition: "transform 0.8s cubic-bezier(0.25,0.46,0.45,0.94)",
              }}
            />
            <div style={{
              position: "absolute", inset: 0,
              background: "rgba(11,11,11,0.55)",
              opacity: hovIdx === i ? 1 : 0,
              transition: "opacity 0.4s ease",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <Instagram size={22} color="#F5F1EA" />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ─── Final CTA ────────────────────────────────────────────────────────────────
function FinalCTA() {
  const { ref, visible } = useReveal(0.15);

  return (
    <section
      ref={ref}
      style={{
        position: "relative", overflow: "hidden",
        minHeight: "clamp(480px, 80vh, 900px)",
        display: "flex", alignItems: "center", justifyContent: "center",
        background: "#0B0B0B",
      }}
    >
      <div style={{ position: "absolute", inset: 0, background: "#0B0B0B" }}>
        <img
          src={IMGS.story4.src}
          alt="Wedding veil silhouette"
          loading="lazy"
          style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center", opacity: 0.28 }}
        />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,11,11,1) 0%, rgba(11,11,11,0.4) 50%, rgba(11,11,11,0.6) 100%)" }} />
      </div>

      <div
        style={{
          position: "relative", zIndex: 10,
          textAlign: "center",
          padding: "clamp(3rem, 8vw, 6rem) clamp(1.5rem, 5vw, 3rem)",
          maxWidth: 900, margin: "0 auto",
          opacity: visible ? 1 : 0,
          transform: visible ? "translateY(0)" : "translateY(28px)",
          transition: "opacity 1.2s ease, transform 1.2s ease",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "1rem", marginBottom: "2rem" }}>
          <div style={{ width: 48, height: 1, background: "rgba(201,169,110,0.5)" }} />
          <span style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase" }}>Begin Your Story</span>
          <div style={{ width: 48, height: 1, background: "rgba(201,169,110,0.5)" }} />
        </div>

        <h2 style={{
          fontFamily: "'Playfair Display', Georgia, serif",
          color: "#F5F1EA",
          fontSize: "clamp(2.2rem, 6.5vw, 5.5rem)",
          fontWeight: 400,
          lineHeight: 1.18,
          marginBottom: "1.5rem",
        }}>
          Your story deserves
          <br />
          <em style={{ color: "#C9A96E", fontStyle: "italic" }}>to be remembered.</em>
        </h2>

        <p style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.45)", fontSize: "13px", letterSpacing: "0.02em", lineHeight: 1.7, marginBottom: "3rem", maxWidth: 380, margin: "0 auto 3rem" }}>
          Limited dates available for 2025 &amp; 2026.<br />Reach out to begin the conversation.
        </p>

        <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem", justifyContent: "center" }}>
          <a
            href="mailto:hello@weddingsbyajay.com"
            style={{
              fontFamily: "'Jost', system-ui, sans-serif",
              fontSize: "10px", letterSpacing: "0.28em", textTransform: "uppercase",
              color: "#0B0B0B", background: "#C9A96E",
              padding: "16px 40px", display: "inline-block", fontWeight: 500,
              textDecoration: "none", transition: "background 0.4s ease",
            }}
            onMouseEnter={e => (e.currentTarget.style.background = "#E8D5A3")}
            onMouseLeave={e => (e.currentTarget.style.background = "#C9A96E")}
          >
            Check Availability
          </a>
          <a
            href="tel:+919000000000"
            style={{
              fontFamily: "'Jost', system-ui, sans-serif",
              fontSize: "10px", letterSpacing: "0.28em", textTransform: "uppercase",
              color: "#F5F1EA", border: "1px solid rgba(245,241,234,0.2)",
              padding: "16px 40px", display: "inline-block",
              textDecoration: "none", transition: "all 0.4s ease",
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "#C9A96E"; e.currentTarget.style.color = "#C9A96E"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(245,241,234,0.2)"; e.currentTarget.style.color = "#F5F1EA"; }}
          >
            +91 90000 00000
          </a>
        </div>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer style={{ background: "#0B0B0B", borderTop: "1px solid rgba(201,169,110,0.1)", padding: "2.5rem clamp(1.5rem, 5vw, 3.5rem)" }}>
      <div style={{ maxWidth: 1680, margin: "0 auto", display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: "1.5rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
          <ImageWithFallback
            src={logoImg}
            alt="W/BA"
            style={{ height: 32, width: 32, objectFit: "contain", mixBlendMode: "screen", opacity: 0.45 }}
          />
          <p style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.2)", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase" }}>
            © 2025 Weddings by Ajay · Hyderabad, India
          </p>
        </div>
        <p style={{ fontFamily: "'Playfair Display', Georgia, serif", fontStyle: "italic", color: "rgba(201,169,110,0.35)", fontSize: "13px" }}>
          Stories that feel like forever.
        </p>
        <div style={{ display: "flex", gap: "2rem" }}>
          {["Instagram", "WhatsApp", "Pinterest"].map(s => (
            <a
              key={s}
              href="#"
              style={{ fontFamily: "'Jost', system-ui, sans-serif", color: "rgba(245,241,234,0.25)", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase", textDecoration: "none", transition: "color 0.3s ease" }}
              onMouseEnter={e => (e.currentTarget.style.color = "#C9A96E")}
              onMouseLeave={e => (e.currentTarget.style.color = "rgba(245,241,234,0.25)")}
            >
              {s}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <div style={{ background: "#0B0B0B", minHeight: "100vh" }}>
      <Navbar />
      <Hero />
      <BrandStatement />
      <FeaturedWeddings />
      <ServicesSection />
      <AboutSection />
      <InstagramSection />
      <FinalCTA />
      <Footer />
    </div>
  );
}
