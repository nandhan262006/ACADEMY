import type { Metadata, Viewport } from "next";
import { Playfair_Display, Jost } from "next/font/google";
import "./globals.css";

// ─── Fonts ────────────────────────────────────────────────────────────────────
const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
  display: "swap",
});

const jost = Jost({
  subsets: ["latin"],
  variable: "--font-jost",
  weight: ["300", "400", "500", "600"],
  display: "swap",
});

// ─── Metadata ─────────────────────────────────────────────────────────────────
export const metadata: Metadata = {
  title: {
    default: "Weddings by Ajay | Luxury Wedding Photography Hyderabad",
    template: "%s | Weddings by Ajay",
  },
  description:
    "Premium cinematic wedding photography and films in Hyderabad, India. Capturing love stories across India and internationally with editorial, emotional storytelling. Est. 2016.",
  keywords: [
    "wedding photographer Hyderabad",
    "luxury wedding photography Hyderabad",
    "Indian wedding photographer",
    "cinematic wedding films Hyderabad",
    "best wedding photographer Hyderabad",
    "destination wedding photographer India",
    "Telugu wedding photographer",
    "candid wedding photography India",
    "wedding photography Telangana",
    "wedding videographer Hyderabad",
    "royal wedding photographer India",
    "film wedding photographer Hyderabad",
  ],
  authors: [{ name: "Ajay Kumar", url: "https://weddingsbyajay.com" }],
  creator: "Weddings by Ajay",
  publisher: "Weddings by Ajay",
  metadataBase: new URL("https://weddingsbyajay.com"),
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: "https://weddingsbyajay.com",
    siteName: "Weddings by Ajay",
    title: "Weddings by Ajay | Luxury Cinematic Wedding Photography Hyderabad",
    description:
      "Stories that feel like forever. Premium cinematic wedding photography and films based in Hyderabad, serving across India.",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Weddings by Ajay — Luxury Cinematic Wedding Photography Hyderabad",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Weddings by Ajay | Luxury Wedding Photography Hyderabad",
    description: "Stories that feel like forever.",
    images: ["/og-image.jpg"],
    creator: "@weddingsbyajay",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: "https://weddingsbyajay.com",
  },
  verification: {
    google: "REPLACE_WITH_GOOGLE_SEARCH_CONSOLE_ID",
  },
  category: "photography",
};

export const viewport: Viewport = {
  themeColor: "#0b0b0b",
  width: "device-width",
  initialScale: 1,
};

// ─── JSON-LD Structured Data ──────────────────────────────────────────────────
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Weddings by Ajay",
  description:
    "Premium cinematic wedding photography and films in Hyderabad, India.",
  url: "https://weddingsbyajay.com",
  logo: "https://weddingsbyajay.com/logo.png",
  image: "https://weddingsbyajay.com/og-image.jpg",
  telephone: "+91-90000-00000",
  email: "hello@weddingsbyajay.com",
  foundingDate: "2016",
  priceRange: "$$$",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Hyderabad",
    addressRegion: "Telangana",
    addressCountry: "IN",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: 17.385,
    longitude: 78.4867,
  },
  areaServed: [
    { "@type": "City", name: "Hyderabad" },
    { "@type": "Country", name: "India" },
  ],
  sameAs: [
    "https://www.instagram.com/weddingsbyajay",
    "https://www.pinterest.com/weddingsbyajay",
  ],
};

// ─── Root Layout ──────────────────────────────────────────────────────────────
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en-IN"
      className={`${playfair.variable} ${jost.variable}`}
    >
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
