"use client";

import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import { Menu, X, ArrowRight, Play, Instagram } from "lucide-react";

// ─── Font CSS variables (set by next/font in layout.tsx) ──────────────────────
const SERIF = "var(--font-playfair), Georgia, serif";
const SANS  = "var(--font-jost), system-ui, sans-serif";

// ─── Unsplash image catalogue ─────────────────────────────────────────────────
const IMGS = {
  hero:   { src: "https://images.unsplash.com/photo-1762708594285-fb55302623fe?fit=crop&auto=format&q=85", alt: "Silhouette of bride beneath a sheer veil at golden dusk" },
  story1: { src: "https://images.unsplash.com/photo-1665960213508-48f07086d49c?fit=crop&auto=format&q=80", alt: "Indian couple in traditional bridal attire" },
  story2: { src: "https://images.unsplash.com/photo-1727430256509-0f897d6f4765?fit=crop&auto=format&q=80", alt: "Couple beneath a romantic canopy of blooms" },
  story3: { src: "https://images.unsplash.com/photo-1735052712464-9d24b69be5f5?fit=crop&auto=format&q=80", alt: "Bride and groom walking a forest path" },
  story4: { src: "https://images.unsplash.com/photo-1779810687374-55d9007b9fbb?fit=crop&auto=format&q=80", alt: "Silhouette covered by a sheer wedding veil" },
  story5: { src: "https://images.unsplash.com/photo-1587271407850-8d438ca9fdf2?fit=crop&auto=format&q=80", alt: "Grand Indian wedding beneath a gold floral ceiling" },
  couple: { src: "https://images.unsplash.com/photo-1559460547-932cc4939506?fit=crop&auto=format&q=80", alt: "Couple in an intimate moment at dusk" },
  about:  { src: "https://images.unsplash.com/photo-1519741196428-6a2175fa2557?fit=crop&auto=format&q=80", alt: "Intimate wedding portrait" },
  film:   { src: "https://images.unsplash.com/photo-1587271636175-90d58cdad458?fit=crop&auto=format&q=80", alt: "Grand Indian wedding ceremony" },
  ig1:    { src: "https://images.unsplash.com/photo-1614618586684-7afae48a15d3?fit=crop&auto=format&q=75", alt: "Bridal portrait in floral gown" },
  ig2:    { src: "https://images.unsplash.com/photo-1735052712489-f45220126a0c?fit=crop&auto=format&q=75", alt: "Bride and groom at sunset" },
  ig3:    { src: "https://images.unsplash.com/photo-1488846343176-08e05ab9a2a1?fit=crop&auto=format&q=75", alt: "Serene bride with eyes closed" },
  ig4:    { src: "https://images.unsplash.com/photo-1630526720753-aa4e71acf67d?fit=crop&auto=format&q=75", alt: "Bride in red and white traditional dress" },
  ig5:    { src: "https://images.unsplash.com/photo-1501175635532-bdd01562edb2?fit=crop&auto=format&q=75", alt: "Bride in wedding veil" },
  ig6:    { src: "https://images.unsplash.com/photo-1484849457281-191e439a0431?fit=crop&auto=format&q=75", alt: "Wedding gown in natural light" },
};

// ─── Scroll-reveal hook ───────────────────────────────────────────────────────
function useReveal(threshold = 0.12) {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) { setVisible(true); obs.disconnect(); }
      },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, visible };
}

// ─── Navbar ───────────────────────────────────────────────────────────────────
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 56);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const links = ["Weddings", "Films", "About", "Contact"];

  return (
    <nav
      style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 50,
        transition: "all 0.7s ease",
        background: scrolled ? "rgba(11,11,11,0.97)" : "transparent",
        borderBottom: scrolled ? "1px solid rgba(201,169,110,0.1)" : "1px solid transparent",
        backdropFilter: scrolled ? "blur(8px)" : "none",
      }}
    >
      <div style={{ maxWidth: 1680, margin: "0 auto", padding: "0 clamp(1.5rem, 5vw, 3.5rem)", display: "flex", alignItems: "center", justifyContent: "space-between", height: "clamp(60px, 8vw, 72px)" }}>

        {/* Logo */}
        <a href="#hero" style={{ display: "flex", alignItems: "center", gap: 12, textDecoration: "none" }}>
          {/* Place LOGO.png in your /public folder */}
          <Image
            src="/LOGO.png"
            alt="W/BA — Weddings by Ajay"
            width={38}
            height={38}
            style={{ objectFit: "contain", mixBlendMode: "screen", display: "block", flexShrink: 0 }}
          />
          <span style={{ fontFamily: SANS, color: "#F5F1EA", fontSize: "10px", letterSpacing: "0.38em", textTransform: "uppercase", fontWeight: 400, opacity: 0.75, display: "var(--wordmark-display, block)" }}>
            Weddings by Ajay
          </span>
        </a>

        {/* Desktop nav */}
        <div className="hidden lg:flex" style={{ gap: "2.5rem" }}>
          {links.map(l => (
            <a
              key={l}
              href={`#${l.toLowerCase()}`}
              style={{ fontFamily: SANS, color: "rgba(245,241,234,0.55)", fontSize: "10px", letterSpacing: "0.35em", textTransform: "uppercase", textDecoration: "none", transition: "color 0.3s ease" }}
              onMouseEnter={e => (e.currentTarget.style.color = "#C9A96E")}
              onMouseLeave={e => (e.currentTarget.style.color = "rgba(245,241,234,0.55)")}
            >
              {l}
            </a>
          ))}
        </div>

        {/* Mobile toggle */}
        <button className="lg:hidden" style={{ color: "#F5F1EA", background: "none", border: "none", cursor: "pointer", padding: 4 }} onClick={() => setOpen(v => !v)} aria-label="Toggle menu">
          {open ? <X size={19} /> : <Menu size={19} />}
        </button>
      </div>

      {/* Mobile panel */}
      <div style={{ maxHeight: open ? "220px" : "0px", overflow: "hidden", transition: "max-height 0.5s ease" }}>
        <div style={{ padding: "0.5rem 1.5rem 2rem", borderTop: "1px solid rgba(201,169,110,0.1)", background: "rgba(11,11,11,0.98)", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
          {links.map(l => (
            <a key={l} href={`#${l.toLowerCase()}`} onClick={() => setOpen(false)} style={{ fontFamily: SANS, color: "rgba(245,241,234,0.65)", fontSize: "10px", letterSpacing: "0.35em", textTransform: "uppercase", textDecoration: "none" }}>
              {l}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  const [ready, setReady] = useState(false);

  return (
    <section id="hero" style={{ position: "relative", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center", height: "100svh", minHeight: 600 }}>

      {/* Background image */}
      <div style={{ position: "absolute", inset: 0, background: "#0B0B0B" }}>
        <Image
          src={IMGS.hero.src}
          alt={IMGS.hero.alt}
          fill
          priority
          sizes="100vw"
          style={{
            objectFit: "cover",
            objectPosition: "center",
            opacity: ready ? 0.52 : 0,
            transition: "opacity 1.4s ease",
          }}
          onLoad={() => setReady(true)}
        />
      </div>

      {/* Overlays */}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(11,11,11,0.5) 0%, rgba(11,11,11,0.05) 40%, rgba(11,11,11,0.05) 60%, rgba(11,11,11,0.85) 100%)" }} />
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at center, transparent 40%, rgba(11,11,11,0.45) 100%)" }} />

      {/* Content */}
      <div
        style={{
          position: "relative", zIndex: 10, display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center",
          padding: "0 1.5rem",
          opacity: ready ? 1 : 0, transform: ready ? "translateY(0)" : "translateY(20px)",
          transition: "opacity 1.2s ease 0.4s, transform 1.2s ease 0.4s",
        }}
      >
        {/* W/BA logo mark */}
        <div style={{ marginBottom: "clamp(1.5rem, 4vw, 2.5rem)" }}>
          <Image
            src="/LOGO.png"
            alt="W/BA — Weddings by Ajay"
            width={160}
            height={160}
            style={{
              width: "clamp(90px, 14vw, 160px)",
              height: "clamp(90px, 14vw, 160px)",
              objectFit: "contain",
              mixBlendMode: "screen",
              display: "block",
            }}
          />
        </div>

        {/* Gold rule + provenance */}
        <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "2rem" }}>
          <div style={{ width: 48, height: 1, background: "rgba(201,169,110,0.55)" }} />
          <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase" }}>
            Est. 2016 · Hyderabad, India
          </span>
          <div style={{ width: 48, height: 1, background: "rgba(201,169,110,0.55)" }} />
        </div>

        <h1 style={{ fontFamily: SERIF, color: "#F5F1EA", fontSize: "clamp(2.4rem, 7vw, 6.5rem)", letterSpacing: "0.16em", textTransform: "uppercase", fontWeight: 400, lineHeight: 1.05, marginBottom: "clamp(0.9rem, 2vw, 1.4rem)" }}>
          Weddings<br />by Ajay
        </h1>

        <p style={{ fontFamily: SERIF, fontStyle: "italic", color: "#C9A96E", fontSize: "clamp(1rem, 2.2vw, 1.45rem)", letterSpacing: "0.06em", marginBottom: "clamp(2.5rem, 5vw, 3.5rem)" }}>
          Stories that feel like forever.
        </p>

        <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem", justifyContent: "center" }}>
          <a
            href="#weddings"
            style={{ fontFamily: SANS, fontSize: "10px", letterSpacing: "0.28em", textTransform: "uppercase", color: "#F5F1EA", border: "1px solid rgba(245,241,234,0.35)", padding: "14px 32px", textDecoration: "none", transition: "all 0.4s ease" }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "#C9A96E"; e.currentTarget.style.color = "#C9A96E"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(245,241,234,0.35)"; e.currentTarget.style.color = "#F5F1EA"; }}
          >
            View Stories
          </a>
          <a
            href="#contact"
            style={{ fontFamily: SANS, fontSize: "10px", letterSpacing: "0.28em", textTransform: "uppercase", color: "#0B0B0B", background: "#C9A96E", padding: "14px 32px", textDecoration: "none", fontWeight: 500, transition: "background 0.4s ease" }}
            onMouseEnter={e => (e.currentTarget.style.background = "#E8D5A3")}
            onMouseLeave={e => (e.currentTarget.style.background = "#C9A96E")}
          >
            Book Your Date
          </a>
        </div>
      </div>

      {/* Scroll pulse */}
      <div style={{ position: "absolute", bottom: 32, left: "50%", transform: "translateX(-50%)", opacity: ready ? 0.35 : 0, transition: "opacity 1s ease 1.8s" }}>
        <div style={{ width: 1, height: 48, background: "#F5F1EA", animation: "scrollPulse 2s ease-in-out infinite" }} />
      </div>
    </section>
  );
}

// ─── Brand Statement ──────────────────────────────────────────────────────────
function BrandStatement() {
  const { ref, visible } = useReveal(0.15);
  return (
    <section ref={ref} style={{ background: "#0B0B0B", padding: "clamp(5rem, 12vw, 11rem) clamp(1.5rem, 5vw, 5rem)" }}>
      <div style={{ maxWidth: 1500, margin: "0 auto" }}>
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_2fr]" style={{ gap: "clamp(3rem, 6vw, 8rem)", alignItems: "center" }}>
          <div style={{ opacity: visible ? 1 : 0, transform: visible ? "translateX(0)" : "translateX(-20px)", transition: "opacity 1s ease, transform 1s ease" }}>
            <div style={{ width: 40, height: 1, background: "#C9A96E", marginBottom: "1rem" }} />
            <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase", display: "block", marginBottom: "1.2rem" }}>Philosophy</span>
            <p style={{ fontFamily: SANS, color: "rgba(245,241,234,0.35)", fontSize: "13px", lineHeight: 1.8 }}>
              Every frame is a deliberate choice. Every moment preserved in its fullest truth — untouched, unrepeatable.
            </p>
          </div>
          <h2 style={{ fontFamily: SERIF, color: "#F5F1EA", fontSize: "clamp(2.2rem, 5.5vw, 5rem)", fontWeight: 400, lineHeight: 1.18, opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(24px)", transition: "opacity 1.1s ease 0.15s, transform 1.1s ease 0.15s" }}>
            We don&apos;t just<br />
            <em style={{ color: "#C9A96E", fontStyle: "italic" }}>capture</em> weddings.<br />
            We preserve the<br />
            feeling.
          </h2>
        </div>
      </div>
    </section>
  );
}

// ─── Featured Weddings ────────────────────────────────────────────────────────
const STORIES = [
  { title: "Priya & Arjun",  location: "Hyderabad", year: "2024", type: "Royal Haveli",        img: IMGS.story1 },
  { title: "Meera & Vikram", location: "Udaipur",   year: "2024", type: "Palace Destination",  img: IMGS.story2 },
  { title: "Ananya & Karan", location: "Goa",       year: "2023", type: "Beachside Romance",   img: IMGS.story3 },
  { title: "Divya & Rohan",  location: "Delhi",     year: "2023", type: "Heritage Garden",     img: IMGS.story4 },
  { title: "Ishaan & Preet", location: "Jaipur",    year: "2024", type: "Maharaja Celebration",img: IMGS.story5 },
];

type Story = (typeof STORIES)[0];

function StoryCard({ story, delay, visible, aspectRatio, sizes = "(max-width:768px) 100vw, 50vw" }: {
  story: Story; delay: number; visible: boolean; aspectRatio: string; sizes?: string;
}) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      style={{
        position: "relative", overflow: "hidden", background: "#111",
        aspectRatio, cursor: "pointer",
        opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(28px)",
        transition: `opacity 1s ease ${delay}ms, transform 1s ease ${delay}ms`,
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <Image
        src={story.img.src}
        alt={story.img.alt}
        fill
        sizes={sizes}
        style={{
          objectFit: "cover",
          transform: hovered ? "scale(1.06)" : "scale(1)",
          transition: "transform 1.6s cubic-bezier(0.25,0.46,0.45,0.94)",
        }}
      />
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,11,11,0.85) 0%, rgba(11,11,11,0.1) 50%, transparent 100%)" }} />
      <div style={{ position: "absolute", top: 20, right: 20, border: "1px solid rgba(201,169,110,0.5)", padding: "5px 12px", opacity: hovered ? 1 : 0, transform: hovered ? "translateY(0)" : "translateY(-6px)", transition: "opacity 0.4s ease, transform 0.4s ease" }}>
        <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "8px", letterSpacing: "0.3em", textTransform: "uppercase" }}>View Story</span>
      </div>
      <div style={{ position: "absolute", bottom: 0, left: 0, padding: "clamp(1.2rem, 3vw, 2rem)" }}>
        <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "8px", letterSpacing: "0.4em", textTransform: "uppercase", display: "block", marginBottom: "0.5rem" }}>{story.type} · {story.year}</span>
        <h3 style={{ fontFamily: SERIF, color: "#F5F1EA", fontSize: "clamp(1.1rem, 2vw, 1.6rem)", fontWeight: 400, marginBottom: "0.3rem" }}>{story.title}</h3>
        <p style={{ fontFamily: SANS, color: "rgba(245,241,234,0.45)", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase" }}>{story.location}</p>
      </div>
    </div>
  );
}

function FeaturedWeddings() {
  const { ref, visible } = useReveal(0.05);
  return (
    <section id="weddings" ref={ref} style={{ background: "#0B0B0B", paddingBottom: "clamp(4rem, 10vw, 9rem)" }}>
      <div style={{ maxWidth: 1680, margin: "0 auto", padding: "clamp(4rem, 8vw, 7rem) clamp(1.5rem, 5vw, 3.5rem) clamp(2rem, 4vw, 3rem)", display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: "1.5rem", opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(16px)", transition: "opacity 0.9s ease, transform 0.9s ease" }}>
        <div>
          <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase", display: "block", marginBottom: "0.75rem" }}>Selected Work</span>
          <h2 style={{ fontFamily: SERIF, color: "#F5F1EA", fontSize: "clamp(2rem, 4.5vw, 4rem)", fontWeight: 400 }}>Featured Stories</h2>
        </div>
        <a href="#" style={{ fontFamily: SANS, color: "rgba(245,241,234,0.4)", fontSize: "10px", letterSpacing: "0.3em", textTransform: "uppercase", display: "flex", alignItems: "center", gap: 8, textDecoration: "none", transition: "color 0.3s ease" }} onMouseEnter={e => (e.currentTarget.style.color = "#C9A96E")} onMouseLeave={e => (e.currentTarget.style.color = "rgba(245,241,234,0.4)")}>
          View All <ArrowRight size={13} />
        </a>
      </div>

      <div style={{ maxWidth: 1680, margin: "0 auto", padding: "0 clamp(1rem, 2vw, 2rem)" }}>
        <div className="grid grid-cols-1 lg:grid-cols-[3fr_2fr]" style={{ gap: 4, marginBottom: 4 }}>
          <StoryCard story={STORIES[0]} aspectRatio="4/3" delay={0}   visible={visible} sizes="(max-width:1024px) 100vw, 60vw" />
          <StoryCard story={STORIES[1]} aspectRatio="3/4" delay={80}  visible={visible} sizes="(max-width:1024px) 100vw, 40vw" />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-[2fr_3fr]" style={{ gap: 4, marginBottom: 4 }}>
          <StoryCard story={STORIES[2]} aspectRatio="3/4" delay={160} visible={visible} sizes="(max-width:1024px) 100vw, 40vw" />
          <StoryCard story={STORIES[3]} aspectRatio="4/3" delay={240} visible={visible} sizes="(max-width:1024px) 100vw, 60vw" />
        </div>
        <StoryCard story={STORIES[4]} aspectRatio="21/9" delay={320} visible={visible} sizes="100vw" />
      </div>
    </section>
  );
}

// ─── Photography + Cinematic Films ────────────────────────────────────────────
function ServicesSection() {
  const { ref, visible } = useReveal(0.08);
  const [hovPh, setHovPh] = useState(false);
  const [hovFi, setHovFi] = useState(false);

  return (
    <section id="films" ref={ref} style={{ background: "#0B0B0B" }}>
      <div style={{ maxWidth: 1680, margin: "0 auto", padding: "0 clamp(1.5rem, 5vw, 3.5rem)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "2rem", padding: "clamp(3rem, 6vw, 6rem) 0 clamp(2rem, 4vw, 4rem)" }}>
          <div style={{ flex: 1, height: 1, background: "rgba(201,169,110,0.1)" }} />
          <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase", whiteSpace: "nowrap" }}>Services</span>
          <div style={{ flex: 1, height: 1, background: "rgba(201,169,110,0.1)" }} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2">
        {/* Photography */}
        <div
          style={{ position: "relative", overflow: "hidden", height: "clamp(420px, 70vh, 820px)", background: "#111", cursor: "pointer", opacity: visible ? 1 : 0, transform: visible ? "translateX(0)" : "translateX(-24px)", transition: "opacity 1.1s ease 0.1s, transform 1.1s ease 0.1s" }}
          onMouseEnter={() => setHovPh(true)}
          onMouseLeave={() => setHovPh(false)}
        >
          <Image
            src={IMGS.couple.src}
            alt={IMGS.couple.alt}
            fill
            sizes="(max-width:1024px) 100vw, 50vw"
            style={{ objectFit: "cover", transform: hovPh ? "scale(1.06)" : "scale(1)", transition: "transform 1.6s cubic-bezier(0.25,0.46,0.45,0.94)" }}
          />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,11,11,0.92) 0%, rgba(11,11,11,0.2) 55%, rgba(11,11,11,0.1) 100%)" }} />
          <div style={{ position: "absolute", bottom: 0, left: 0, padding: "clamp(2rem, 4vw, 3.5rem)" }}>
            <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.4em", textTransform: "uppercase", display: "block", marginBottom: "1rem" }}>01 ·</span>
            <h3 style={{ fontFamily: SERIF, color: "#F5F1EA", fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 400, marginBottom: "1rem" }}>Photography</h3>
            <p style={{ fontFamily: SANS, color: "rgba(245,241,234,0.55)", fontSize: "13px", lineHeight: 1.8, maxWidth: 300, marginBottom: "1.5rem" }}>Still frames that hold the weight of a moment. Candid, intimate, editorial — photographs that become heirlooms.</p>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 32, height: 1, background: "#C9A96E" }} />
              <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase" }}>Explore</span>
            </div>
          </div>
        </div>

        {/* Cinematic Films */}
        <div
          style={{ position: "relative", overflow: "hidden", height: "clamp(420px, 70vh, 820px)", background: "#111", cursor: "pointer", opacity: visible ? 1 : 0, transform: visible ? "translateX(0)" : "translateX(24px)", transition: "opacity 1.1s ease 0.25s, transform 1.1s ease 0.25s" }}
          onMouseEnter={() => setHovFi(true)}
          onMouseLeave={() => setHovFi(false)}
        >
          <Image
            src={IMGS.film.src}
            alt={IMGS.film.alt}
            fill
            sizes="(max-width:1024px) 100vw, 50vw"
            style={{ objectFit: "cover", objectPosition: "center top", transform: hovFi ? "scale(1.06)" : "scale(1)", transition: "transform 1.6s cubic-bezier(0.25,0.46,0.45,0.94)" }}
          />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,11,11,0.92) 0%, rgba(11,11,11,0.35) 55%, rgba(11,11,11,0.15) 100%)" }} />
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ width: 64, height: 64, border: `1px solid ${hovFi ? "#C9A96E" : "rgba(201,169,110,0.5)"}`, display: "flex", alignItems: "center", justifyContent: "center", background: hovFi ? "rgba(201,169,110,0.12)" : "transparent", transition: "all 0.4s ease" }}>
              <Play size={20} fill="#C9A96E" color="#C9A96E" style={{ marginLeft: 3 }} />
            </div>
          </div>
          <div style={{ position: "absolute", bottom: 0, left: 0, padding: "clamp(2rem, 4vw, 3.5rem)" }}>
            <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.4em", textTransform: "uppercase", display: "block", marginBottom: "1rem" }}>02 ·</span>
            <h3 style={{ fontFamily: SERIF, color: "#F5F1EA", fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 400, marginBottom: "1rem" }}>Cinematic Films</h3>
            <p style={{ fontFamily: SANS, color: "rgba(245,241,234,0.55)", fontSize: "13px", lineHeight: 1.8, maxWidth: 300, marginBottom: "1.5rem" }}>Feature-length wedding films crafted like cinema. Scored with emotion. Made to be rewatched for a lifetime.</p>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 32, height: 1, background: "#C9A96E" }} />
              <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase" }}>Watch Reel</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── About ────────────────────────────────────────────────────────────────────
function AboutSection() {
  const { ref, visible } = useReveal(0.08);
  return (
    <section id="about" ref={ref} style={{ background: "#0B0B0B", padding: "clamp(5rem, 12vw, 11rem) clamp(1.5rem, 5vw, 3.5rem)" }}>
      <div style={{ maxWidth: 1500, margin: "0 auto" }}>
        <div style={{ height: 1, background: "rgba(201,169,110,0.1)", marginBottom: "clamp(3rem, 7vw, 6rem)" }} />
        <div className="grid grid-cols-1 lg:grid-cols-2" style={{ gap: "clamp(3rem, 7vw, 7rem)", alignItems: "start" }}>

          {/* Portrait */}
          <div style={{ position: "relative", opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(28px)", transition: "opacity 1.1s ease, transform 1.1s ease" }}>
            <div style={{ aspectRatio: "4/5", position: "relative", overflow: "hidden", background: "#111" }}>
              <Image
                src={IMGS.about.src}
                alt={IMGS.about.alt}
                fill
                sizes="(max-width:1024px) 100vw, 50vw"
                style={{ objectFit: "cover" }}
              />
            </div>
            <div style={{ position: "absolute", bottom: -16, right: -16, width: "55%", height: "40%", border: "1px solid rgba(201,169,110,0.22)", pointerEvents: "none" }} />
          </div>

          {/* Text */}
          <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(28px)", transition: "opacity 1.1s ease 0.2s, transform 1.1s ease 0.2s" }}>
            <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase", display: "block", marginBottom: "1.5rem" }}>About</span>
            <h2 style={{ fontFamily: SERIF, color: "#F5F1EA", fontSize: "clamp(2.5rem, 4.5vw, 4rem)", fontWeight: 400, lineHeight: 1.1, marginBottom: "2rem" }}>Ajay Kumar</h2>
            <p style={{ fontFamily: SANS, color: "rgba(245,241,234,0.58)", fontSize: "14px", lineHeight: 1.85, marginBottom: "1.25rem" }}>
              Based in Hyderabad, Ajay has spent over a decade perfecting the art of wedding storytelling. What began as a quiet passion for documentary photography has evolved into one of India&apos;s most sought-after wedding studios.
            </p>
            <p style={{ fontFamily: SANS, color: "rgba(245,241,234,0.58)", fontSize: "14px", lineHeight: 1.85, marginBottom: "2.5rem" }}>
              His approach is rooted in restraint — a belief that the most powerful images are those that feel discovered rather than constructed. He and his team travel across India and internationally, from intimate ceremonies to grand royal celebrations.
            </p>
            <blockquote style={{ borderLeft: "2px solid #C9A96E", paddingLeft: "1.5rem", marginBottom: "2.5rem" }}>
              <p style={{ fontFamily: SERIF, fontStyle: "italic", color: "rgba(245,241,234,0.78)", fontSize: "clamp(1rem, 1.8vw, 1.25rem)", lineHeight: 1.7 }}>
                &ldquo;I&apos;m not here to make pretty pictures. I&apos;m here to make sure, thirty years from now, you can still feel what that day felt like.&rdquo;
              </p>
            </blockquote>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1.5rem", borderTop: "1px solid rgba(201,169,110,0.1)", paddingTop: "2rem" }}>
              {[["400+", "Weddings"], ["12", "Years"], ["18", "Countries"]].map(([n, l]) => (
                <div key={l}>
                  <div style={{ fontFamily: SERIF, color: "#C9A96E", fontSize: "clamp(1.8rem, 3vw, 2.5rem)", fontWeight: 400, lineHeight: 1, marginBottom: "0.4rem" }}>{n}</div>
                  <div style={{ fontFamily: SANS, color: "rgba(245,241,234,0.35)", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase" }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Instagram Grid ───────────────────────────────────────────────────────────
const IG = [IMGS.ig1, IMGS.ig2, IMGS.ig3, IMGS.ig4, IMGS.ig5, IMGS.ig6];

function InstagramSection() {
  const { ref, visible } = useReveal(0.05);
  const [hovIdx, setHovIdx] = useState<number | null>(null);

  return (
    <section id="contact" ref={ref} style={{ background: "#0B0B0B", paddingTop: "clamp(4rem, 10vw, 8rem)" }}>
      <div style={{ maxWidth: 1680, margin: "0 auto", padding: "0 clamp(1.5rem, 5vw, 3.5rem) clamp(2.5rem, 5vw, 4rem)", display: "flex", flexWrap: "wrap", alignItems: "flex-end", justifyContent: "space-between", gap: "1.5rem", opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(16px)", transition: "opacity 0.9s ease, transform 0.9s ease" }}>
        <div>
          <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase", display: "block", marginBottom: "0.75rem" }}>Follow the Stories</span>
          <h2 style={{ fontFamily: SERIF, color: "#F5F1EA", fontSize: "clamp(1.8rem, 4vw, 3.5rem)", fontWeight: 400 }}>@weddingsbyajay</h2>
        </div>
        <a href="https://instagram.com/weddingsbyajay" target="_blank" rel="noopener noreferrer" style={{ fontFamily: SANS, color: "rgba(245,241,234,0.4)", fontSize: "10px", letterSpacing: "0.3em", textTransform: "uppercase", display: "flex", alignItems: "center", gap: 8, textDecoration: "none", transition: "color 0.3s ease" }} onMouseEnter={e => (e.currentTarget.style.color = "#C9A96E")} onMouseLeave={e => (e.currentTarget.style.color = "rgba(245,241,234,0.4)")}>
          <Instagram size={13} /> Follow on Instagram
        </a>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3" style={{ gap: 2 }}>
        {IG.map((img, i) => (
          <div
            key={i}
            style={{ position: "relative", overflow: "hidden", background: "#111", aspectRatio: "1/1", cursor: "pointer", opacity: visible ? 1 : 0, transform: visible ? "scale(1)" : "scale(0.97)", transition: `opacity 0.9s ease ${i * 70}ms, transform 0.9s ease ${i * 70}ms` }}
            onMouseEnter={() => setHovIdx(i)}
            onMouseLeave={() => setHovIdx(null)}
          >
            <Image
              src={img.src}
              alt={img.alt}
              fill
              sizes="(max-width:768px) 50vw, 33vw"
              style={{ objectFit: "cover", transform: hovIdx === i ? "scale(1.08)" : "scale(1)", transition: "transform 0.8s cubic-bezier(0.25,0.46,0.45,0.94)" }}
            />
            <div style={{ position: "absolute", inset: 0, background: "rgba(11,11,11,0.55)", opacity: hovIdx === i ? 1 : 0, transition: "opacity 0.4s ease", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Instagram size={22} color="#F5F1EA" />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ─── Final CTA ────────────────────────────────────────────────────────────────
function FinalCTA() {
  const { ref, visible } = useReveal(0.15);
  return (
    <section ref={ref} style={{ position: "relative", overflow: "hidden", minHeight: "clamp(480px, 80vh, 900px)", display: "flex", alignItems: "center", justifyContent: "center", background: "#0B0B0B" }}>
      <div style={{ position: "absolute", inset: 0 }}>
        <Image
          src={IMGS.story4.src}
          alt="Wedding veil silhouette"
          fill
          sizes="100vw"
          style={{ objectFit: "cover", objectPosition: "center", opacity: 0.28 }}
        />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,11,11,1) 0%, rgba(11,11,11,0.4) 50%, rgba(11,11,11,0.6) 100%)" }} />
      </div>

      <div style={{ position: "relative", zIndex: 10, textAlign: "center", padding: "clamp(3rem, 8vw, 6rem) clamp(1.5rem, 5vw, 3rem)", maxWidth: 900, margin: "0 auto", opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(28px)", transition: "opacity 1.2s ease, transform 1.2s ease" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "1rem", marginBottom: "2rem" }}>
          <div style={{ width: 48, height: 1, background: "rgba(201,169,110,0.5)" }} />
          <span style={{ fontFamily: SANS, color: "#C9A96E", fontSize: "9px", letterSpacing: "0.45em", textTransform: "uppercase" }}>Begin Your Story</span>
          <div style={{ width: 48, height: 1, background: "rgba(201,169,110,0.5)" }} />
        </div>
        <h2 style={{ fontFamily: SERIF, color: "#F5F1EA", fontSize: "clamp(2.2rem, 6.5vw, 5.5rem)", fontWeight: 400, lineHeight: 1.18, marginBottom: "1.5rem" }}>
          Your story deserves<br />
          <em style={{ color: "#C9A96E", fontStyle: "italic" }}>to be remembered.</em>
        </h2>
        <p style={{ fontFamily: SANS, color: "rgba(245,241,234,0.45)", fontSize: "13px", lineHeight: 1.7, marginBottom: "3rem", maxWidth: 380, marginLeft: "auto", marginRight: "auto" }}>
          Limited dates available for 2025 &amp; 2026.<br />Reach out to begin the conversation.
        </p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem", justifyContent: "center" }}>
          <a
            href="mailto:hello@weddingsbyajay.com"
            style={{ fontFamily: SANS, fontSize: "10px", letterSpacing: "0.28em", textTransform: "uppercase", color: "#0B0B0B", background: "#C9A96E", padding: "16px 40px", textDecoration: "none", fontWeight: 500, transition: "background 0.4s ease" }}
            onMouseEnter={e => (e.currentTarget.style.background = "#E8D5A3")}
            onMouseLeave={e => (e.currentTarget.style.background = "#C9A96E")}
          >
            Check Availability
          </a>
          <a
            href="tel:+919000000000"
            style={{ fontFamily: SANS, fontSize: "10px", letterSpacing: "0.28em", textTransform: "uppercase", color: "#F5F1EA", border: "1px solid rgba(245,241,234,0.2)", padding: "16px 40px", textDecoration: "none", transition: "all 0.4s ease" }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "#C9A96E"; e.currentTarget.style.color = "#C9A96E"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(245,241,234,0.2)"; e.currentTarget.style.color = "#F5F1EA"; }}
          >
            +91 90000 00000
          </a>
        </div>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer style={{ background: "#0B0B0B", borderTop: "1px solid rgba(201,169,110,0.1)", padding: "2.5rem clamp(1.5rem, 5vw, 3.5rem)" }}>
      <div style={{ maxWidth: 1680, margin: "0 auto", display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: "1.5rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <Image src="/LOGO.png" alt="W/BA" width={32} height={32} style={{ objectFit: "contain", mixBlendMode: "screen", opacity: 0.45 }} />
          <p style={{ fontFamily: SANS, color: "rgba(245,241,234,0.2)", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase" }}>
            © 2025 Weddings by Ajay · Hyderabad, India
          </p>
        </div>
        <p style={{ fontFamily: SERIF, fontStyle: "italic", color: "rgba(201,169,110,0.35)", fontSize: "13px" }}>
          Stories that feel like forever.
        </p>
        <div style={{ display: "flex", gap: "2rem" }}>
          {["Instagram", "WhatsApp", "Pinterest"].map(s => (
            <a key={s} href="#" style={{ fontFamily: SANS, color: "rgba(245,241,234,0.25)", fontSize: "9px", letterSpacing: "0.35em", textTransform: "uppercase", textDecoration: "none", transition: "color 0.3s ease" }} onMouseEnter={e => (e.currentTarget.style.color = "#C9A96E")} onMouseLeave={e => (e.currentTarget.style.color = "rgba(245,241,234,0.25)")}>
              {s}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function HomePage() {
  return (
    <main style={{ background: "#0B0B0B", minHeight: "100vh" }}>
      <Navbar />
      <Hero />
      <BrandStatement />
      <FeaturedWeddings />
      <ServicesSection />
      <AboutSection />
      <InstagramSection />
      <FinalCTA />
      <Footer />
    </main>
  );
}
