
  # Premium Wedding Photography Website

  This is a code bundle for Premium Wedding Photography Website. The original project is available at https://www.figma.com/design/Ghc6dSUjSVC7VsMupLimqV/Premium-Wedding-Photography-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  